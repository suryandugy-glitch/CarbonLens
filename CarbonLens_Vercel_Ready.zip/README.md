# CarbonLens — Vercel-ready

Static, zero-backend prototype for individual and campus carbon-footprint tracking.

## Deploy to Vercel
1. Extract this folder.
2. Import the folder/repository into Vercel.
3. Framework preset: **Other**.
4. Build command: leave empty.
5. Output directory: `.`.
6. Deploy.

No Node/Express server or database is required. Activity data is stored in the browser with localStorage. The campus dataset is synthetic demo data.

## Mandatory requirements covered
- Travel, electricity, food and waste logging.
- Activity-based CO2e calculations with documented factor sources.
- Personal and campus dashboards with monthly trends.
- Category breakdown and 160 kg/person/month benchmark.
- Personalized recommendations sorted by estimated CO2e saved.
- Challenges with daily check-ins and tracked savings.
- Hostel, department and team leaderboards.

## Bonus features
- Electricity-bill OCR using Tesseract.js.
- Trip CSV import.
- Informational offset/verification guidance.
- PDF sustainability report export.
- CSV activity export.
- One-click persistent light/dark mode.

## Sources
- UK Government, GHG Conversion Factors 2026: https://www.gov.uk/government/publications/greenhouse-gas-reporting-conversion-factors-2026
- Central Electricity Authority, CO2 Baseline Database: https://cea.nic.in/cdm-co2-baseline-database/?lang=en
- Our World in Data, food footprint data: https://ourworldindata.org/grapher/ghg-per-kg-poore
- US EPA, GHG Emission Factors Hub: https://www.epa.gov/climateleadership/ghg-emission-factors-hub

The displayed transport and meal values are application defaults for a demonstrator. Formal reporting should use factors appropriate to the institution, geography, fuel/mode and reporting year.
